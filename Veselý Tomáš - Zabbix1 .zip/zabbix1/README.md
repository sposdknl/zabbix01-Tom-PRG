# Zabbix Auto-registration - Tomáš Veselý

## Implementace úkolu
- **Hostname:** zbx-veselyt-001
- **IP adresa:** 86.49.188.67
- **Distribuce:** Ubuntu 22.04 LTS (Jammy)
- **Zabbix Agent:** 7.0.21 LTS
- **Zabbix Server:** enceladus.pfsense.cz
- **Host Metadata:** SPOS
- **Datum dokončení:** 7.11.2025

## Postup realizace
1. Naklonován repozitář z GitHubu
2. Upraven Vagrantfile - hostname: zbx-veselyt-001
3. Upraven install-zabbix-agent2.sh - změna na Zabbix 7.0 LTS
4. Upraven configure-zabbix-agent2.sh - nastavení pevného hostname
5. Spuštěn příkaz `vagrant up`
6. Host úspěšně zaregistrován na Zabbix serveru Enceladus
7. Vytvořen screenshot registrovaného hosta
8. Exportován host do YAML formátu

## Struktura projektu
```
zabbix1/
├── Vagrantfile
├── install-zabbix-agent2.sh
├── configure-zabbix-agent2.sh
├── README.md
├── Images/
│   └── host.png
└── Export/
    └── zabbix_export_hosts.yaml
```

## Screenshots
![Registrovaný host](Images/host.png)