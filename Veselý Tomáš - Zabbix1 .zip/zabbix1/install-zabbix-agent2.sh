#!/usr/bin/env bash
# Instalace balicku net-tools
sudo apt-get install -y net-tools

# Stažení balíčku pro instalaci zabbix repo 7.0 LTS
sudo wget https://repo.zabbix.com/zabbix/7.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_latest_7.0+ubuntu22.04_all.deb

# Instalace meta balíčku
sudo dpkg -i zabbix-release_latest_7.0+ubuntu22.04_all.deb

# Aktualizace repository
sudo apt-get update

# Instalace Zabbix Agent2 7.0 LTS
sudo apt-get install -y zabbix-agent2 zabbix-agent2-plugin-*

# Povoleni sluzby zabbix-agent2
sudo systemctl enable zabbix-agent2

# Restart sluzby zabbix-agent2
sudo systemctl restart zabbix-agent2

echo "=== Zabbix Agent2 7.0 LTS nainstalovano ==="

# EOF